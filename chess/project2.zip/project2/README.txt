Written by Thomas Schelske - schel433

No partner.

To run the program, compile the Game.java file. Once it's compiled you can run it and it will ask whether or not you want
to play chess. Any input other than "yes" or "Yes" will stop the program. If we did get one of the yes's, a chess board is
loaded onto the terminal. It would likely be best to play this chess with two players since there is no
AI or online form of multiplayer.

“I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”

TJS
